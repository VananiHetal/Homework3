public class IfElseExample {

    public static void main(String[] args) {
// check if the number is divisible by 2 or not
        if ("number" % 2 == 0) {
            System.out.println("even number");
        } else {

            System.out.println("od number");

        }

    }
}


